package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.lifecycle.lifecycleScope
import com.example.data.AttendanceDatabase
import com.example.data.AttendanceRepository
import com.example.ui.AttendanceScreen
import com.example.ui.AttendanceViewModel
import com.example.ui.AttendanceViewModelFactory
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    // Initialize Database & Repository
    val database = AttendanceDatabase.getDatabase(this, lifecycleScope)
    val repository = AttendanceRepository(database.attendanceDao())
    val factory = AttendanceViewModelFactory(repository)

    // Obtain ViewModel
    val viewModel: AttendanceViewModel by viewModels { factory }

    setContent {
      MyApplicationTheme {
        AttendanceScreen(viewModel = viewModel)
      }
    }
  }
}
