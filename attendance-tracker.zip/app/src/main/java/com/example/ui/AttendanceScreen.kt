package com.example.ui

import android.app.DatePickerDialog
import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.animation.core.animateFloatAsState
import kotlinx.coroutines.flow.StateFlow
import com.example.data.AttendanceStatus
import com.example.data.AttendanceRecord
import com.example.data.Student
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.*

// Colors for status representations
val ColorPresent = Color(0xFFB6FFB6) // Soft Light Green
val ColorAbsent = Color(0xFFF2B8B5)  // Soft Light Red
val ColorLate = Color(0xFFFFD54F)    // Warm Soft Yellow
val ColorExcused = Color(0xFF90CAF9) // Soft Light Blue
val ColorUnmarked = Color(0xFF938F99) // Neutral Grey

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AttendanceScreen(
    viewModel: AttendanceViewModel,
    modifier: Modifier = Modifier
) {
    val selectedDateStr by viewModel.selectedDate.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val statusFilter by viewModel.statusFilter.collectAsStateWithLifecycle()
    
    val students by viewModel.students.collectAsStateWithLifecycle()
    val attendanceRows by viewModel.attendanceRows.collectAsStateWithLifecycle()
    val historySummaries by viewModel.historySummaries.collectAsStateWithLifecycle()
    val studentStats by viewModel.studentStats.collectAsStateWithLifecycle()
    val currentDateRecords by viewModel.currentDateRecords.collectAsStateWithLifecycle()

    var activeTab by remember { mutableStateOf(0) } // 0: Mark, 1: History, 2: Students
    
    // Dialog control states
    var showAddStudentDialog by remember { mutableStateOf(false) }
    var selectedStudentForDetail by remember { mutableStateOf<Student?>(null) }

    val context = LocalContext.current
    val selectedDate = remember(selectedDateStr) { LocalDate.parse(selectedDateStr) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            Surface(
                tonalElevation = 8.dp,
                shadowElevation = 4.dp
            ) {
                Column(
                    modifier = Modifier
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                                    MaterialTheme.colorScheme.surface
                                )
                            )
                        )
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    // Header text and system Date picker
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Circular Purple Decorative Menu Logo
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF4F378B)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Menu,
                                    contentDescription = "Menu",
                                    tint = Color(0xFFEADDFF),
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            Column {
                                Text(
                                    text = "Asistencia",
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = (-0.2).sp
                                    ),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Control de Alumnos",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        
                        IconButton(
                            onClick = {
                                val cal = Calendar.getInstance()
                                DatePickerDialog(
                                    context,
                                    { _, y, m, d ->
                                        val date = LocalDate.of(y, m + 1, d)
                                        viewModel.updateSelectedDate(date.toString())
                                    },
                                    selectedDate.year,
                                    selectedDate.monthValue - 1,
                                    selectedDate.dayOfMonth
                                ).show()
                            },
                            colors = IconButtonDefaults.iconButtonColors(
                                containerColor = Color(0xFF49454F),
                                contentColor = Color(0xFFCAC4D0)
                            ),
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .testTag("date_picker_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.DateRange,
                                contentDescription = "Seleccionar Fecha",
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Date quick scroll list
                    CalendarStrip(
                        selectedDate = selectedDate,
                        onDateSelected = { date -> viewModel.updateSelectedDate(date.toString()) }
                    )
                }
            }
        },
        floatingActionButton = {
            if (activeTab == 2) {
                FloatingActionButton(
                    onClick = { showAddStudentDialog = true },
                    containerColor = Color(0xFFD0BCFF),
                    contentColor = Color(0xFF381E72),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .navigationBarsPadding()
                        .testTag("add_student_fab")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Añadir Alumno",
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF1C1B1F),
                contentColor = Color(0xFFCAC4D0),
                tonalElevation = 0.dp,
                modifier = Modifier
                    .height(80.dp)
                    .border(width = 1.dp, color = Color(0xFF49454F), shape = RoundedCornerShape(topStart = 0.dp, topEnd = 0.dp))
                    .navigationBarsPadding()
            ) {
                NavigationBarItem(
                    selected = activeTab == 0,
                    onClick = { activeTab = 0 },
                    icon = {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (activeTab == 0) Color(0xFF332D41) else Color.Transparent)
                                .padding(horizontal = 16.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Asistencia",
                                tint = if (activeTab == 0) Color(0xFFEADDFF) else Color(0xFFCAC4D0)
                            )
                        }
                    },
                    label = {
                        Text(
                            text = "Log",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (activeTab == 0) Color(0xFFEADDFF) else Color(0xFFCAC4D0)
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = Color.Transparent
                    ),
                    modifier = Modifier.testTag("tab_attendance")
                )

                NavigationBarItem(
                    selected = activeTab == 1,
                    onClick = { activeTab = 1 },
                    icon = {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (activeTab == 1) Color(0xFF332D41) else Color.Transparent)
                                .padding(horizontal = 16.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.List,
                                contentDescription = "Historial",
                                tint = if (activeTab == 1) Color(0xFFEADDFF) else Color(0xFFCAC4D0)
                            )
                        }
                    },
                    label = {
                        Text(
                            text = "Stats",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (activeTab == 1) Color(0xFFEADDFF) else Color(0xFFCAC4D0)
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = Color.Transparent
                    ),
                    modifier = Modifier.testTag("tab_history")
                )

                NavigationBarItem(
                    selected = activeTab == 2,
                    onClick = { activeTab = 2 },
                    icon = {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (activeTab == 2) Color(0xFF332D41) else Color.Transparent)
                                .padding(horizontal = 16.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Alumnos",
                                tint = if (activeTab == 2) Color(0xFFEADDFF) else Color(0xFFCAC4D0)
                            )
                        }
                    },
                    label = {
                        Text(
                            text = "Manage",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (activeTab == 2) Color(0xFFEADDFF) else Color(0xFFCAC4D0)
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = Color.Transparent
                    ),
                    modifier = Modifier.testTag("tab_students")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (activeTab) {
                0 -> AttendanceTabContent(
                    viewModel = viewModel,
                    selectedDate = selectedDate,
                    searchQuery = searchQuery,
                    statusFilter = statusFilter,
                    attendanceRows = attendanceRows,
                    totalStudentsCount = students.size,
                    currentDateRecords = currentDateRecords
                )
                1 -> HistoryTabContent(
                    viewModel = viewModel,
                    historySummaries = historySummaries,
                    onDateSelected = { dateStr ->
                        viewModel.updateSelectedDate(dateStr)
                        activeTab = 0
                    }
                )
                2 -> StudentsTabContent(
                    viewModel = viewModel,
                    studentStats = studentStats,
                    onStudentClicked = { student -> selectedStudentForDetail = student }
                )
            }
        }
    }

    // Dialog: Add Student
    if (showAddStudentDialog) {
        AddStudentDialog(
            onDismiss = { showAddStudentDialog = false },
            onConfirm = { last, first ->
                viewModel.addStudent(last, first)
                showAddStudentDialog = false
            }
        )
    }

    // Dialog: Student Detail (History logs + Delete/Edit options)
    selectedStudentForDetail?.let { student ->
        StudentDetailDialog(
            student = student,
            allRecords = viewModel.allRecords,
            onDismiss = { selectedStudentForDetail = null },
            onDelete = {
                viewModel.deleteStudent(student)
                selectedStudentForDetail = null
            },
            onEdit = { editedLastName, editedFirstName ->
                viewModel.editStudent(student.copy(lastName = editedLastName, firstName = editedFirstName))
                // Refresh local state to update the shown dialog text
                selectedStudentForDetail = student.copy(lastName = editedLastName, firstName = editedFirstName)
            }
        )
    }
}

@Composable
fun CalendarStrip(
    selectedDate: LocalDate,
    onDateSelected: (LocalDate) -> Unit
) {
    val listState = rememberLazyListState()
    
    // Generate 14 days around the selected date (10 past, 3 future)
    val dates = remember(selectedDate) {
        (-10..3).map { selectedDate.plusDays(it.toLong()) }
    }

    // Scroll to center selected item automatically
    LaunchedEffect(selectedDate) {
        listState.animateScrollToItem(10) // 10 is the index of selectedDate
    }

    LazyRow(
        state = listState,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(horizontal = 4.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        items(dates) { date ->
            val isSelected = date == selectedDate
            val dayOfWeek = date.format(DateTimeFormatter.ofPattern("EEE", Locale("es", "ES")))
                .replaceFirstChar { it.uppercase() }
            val dayOfMonth = date.dayOfMonth.toString()
            
            val containerColor = if (isSelected) Color(0xFFEADDFF) else Color.Transparent
            val contentColor = if (isSelected) Color(0xFF21005D) else Color(0xFFCAC4D0)
            val borderColor = if (isSelected) Color.Transparent else Color(0xFF49454F)

            Card(
                modifier = Modifier
                    .width(62.dp)
                    .clickable { onDateSelected(date) },
                colors = CardDefaults.cardColors(containerColor = containerColor),
                shape = RoundedCornerShape(12.dp),
                border = borderStroke(1.dp, borderColor)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = dayOfWeek,
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                        color = contentColor.copy(alpha = 0.8f)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = dayOfMonth,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = contentColor
                    )
                }
            }
        }
    }
}

private fun borderStroke(width: androidx.compose.ui.unit.Dp, color: Color) = androidx.compose.foundation.BorderStroke(width, color)

@Composable
fun AttendanceTabContent(
    viewModel: AttendanceViewModel,
    selectedDate: LocalDate,
    searchQuery: String,
    statusFilter: AttendanceFilter,
    attendanceRows: List<AttendanceRow>,
    totalStudentsCount: Int,
    currentDateRecords: List<AttendanceRecord>
) {
    val formattedDate = remember(selectedDate) {
        selectedDate.format(DateTimeFormatter.ofPattern("EEEE d 'de' MMMM, yyyy", Locale("es", "ES")))
            .replaceFirstChar { it.uppercase() }
    }

    val markedCount = currentDateRecords.size
    val unmarkedCount = (totalStudentsCount - markedCount).coerceAtLeast(0)

    Column(modifier = Modifier.fillMaxSize()) {
        // Summary Stats (Geometric Balance & Elegant Dark)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Card 1: Presentes Hoy (Elegant Purple)
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .height(120.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF4F378B)),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = Color(0xFFEADDFF),
                            modifier = Modifier.size(24.dp)
                        )
                        Column {
                            val presentCount = currentDateRecords.count { it.status == AttendanceStatus.PRESENT }
                            Text(
                                text = String.format("%02d", presentCount),
                                style = MaterialTheme.typography.headlineLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 32.sp,
                                    color = Color(0xFFEADDFF)
                                )
                            )
                            Text(
                                text = "Presentes Hoy",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp,
                                    color = Color(0xFFEADDFF).copy(alpha = 0.8f)
                                )
                            )
                        }
                    }
                }

                // Card 2: Ausentes (Elegant Dark Purple/Grey)
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .height(120.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF332D41)),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = null,
                            tint = Color(0xFFE8DEF8),
                            modifier = Modifier.size(24.dp)
                        )
                        Column {
                            val absentCount = currentDateRecords.count { it.status == AttendanceStatus.ABSENT }
                            Text(
                                text = String.format("%02d", absentCount),
                                style = MaterialTheme.typography.headlineLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 32.sp,
                                    color = Color(0xFFE8DEF8)
                                )
                            )
                            Text(
                                text = "Ausentes",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp,
                                    color = Color(0xFFE8DEF8).copy(alpha = 0.8f)
                                )
                            )
                        }
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            // Sub-row displaying other states in a premium horizontal strip
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF2B2930))
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Tardes
                val lateCount = currentDateRecords.count { it.status == AttendanceStatus.LATE }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(ColorLate))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Tardes: $lateCount",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFE6E1E5)
                    )
                }
                
                // Justificados
                val excusedCount = currentDateRecords.count { it.status == AttendanceStatus.EXCUSED }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(ColorExcused))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Justificados: $excusedCount",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFE6E1E5)
                    )
                }

                // Sin marcar
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(ColorUnmarked))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Sin marcar: $unmarkedCount",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                        color = if (unmarkedCount > 0) Color(0xFFD0BCFF) else Color(0xFFB6FFB6)
                    )
                }
            }
        }

        // Search Bar and quick status Filters
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.updateSearchQuery(it) },
            placeholder = { Text("Buscar alumno...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Buscar") },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                        Icon(Icons.Default.Clear, contentDescription = "Limpiar")
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .testTag("attendance_search_input")
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Quick filter horizontal list
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val filters = listOf(
                AttendanceFilter.ALL to "Todos",
                AttendanceFilter.UNMARKED to "Sin Marcar",
                AttendanceFilter.PRESENT to "Presentes",
                AttendanceFilter.ABSENT to "Ausentes",
                AttendanceFilter.LATE to "Tardes",
                AttendanceFilter.EXCUSED to "Justificados"
            )

            items(filters) { (filter, label) ->
                val isSelected = statusFilter == filter
                FilterChip(
                    selected = isSelected,
                    onClick = { viewModel.updateStatusFilter(filter) },
                    label = { Text(label, fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = when (filter) {
                            AttendanceFilter.ALL -> MaterialTheme.colorScheme.primary
                            AttendanceFilter.UNMARKED -> ColorUnmarked
                            AttendanceFilter.PRESENT -> ColorPresent
                            AttendanceFilter.ABSENT -> ColorAbsent
                            AttendanceFilter.LATE -> ColorLate
                            AttendanceFilter.EXCUSED -> ColorExcused
                        },
                        selectedLabelColor = Color.White
                    ),
                    modifier = Modifier.testTag("filter_chip_${filter.name.lowercase()}")
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Quick Actions Row (Mark All Present, Clear)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = { viewModel.markAllForSelectedDate(AttendanceStatus.PRESENT) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = ColorPresent,
                    contentColor = Color.White
                ),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                modifier = Modifier
                    .height(32.dp)
                    .testTag("mark_all_present_button")
            ) {
                Text("Todo Presente", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            TextButton(
                onClick = { viewModel.clearAllForSelectedDate() },
                colors = ButtonDefaults.textButtonColors(
                    contentColor = MaterialTheme.colorScheme.error
                ),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                modifier = Modifier
                    .height(32.dp)
                    .testTag("clear_all_button")
            ) {
                Icon(Icons.Default.Delete, contentDescription = "Reiniciar", modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Reiniciar", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Large Students Attendance List
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 16.dp)
        ) {
            if (attendanceRows.isEmpty()) {
                item {
                    EmptyState(
                        title = "No hay alumnos coincidentes",
                        description = "Prueba con otra búsqueda o filtro de estado."
                    )
                }
            } else {
                items(attendanceRows, key = { it.student.id }) { row ->
                    AttendanceRowItem(
                        row = row,
                        onStatusChanged = { status ->
                            viewModel.updateAttendance(row.student.id, status)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun AttendanceRowItem(
    row: AttendanceRow,
    onStatusChanged: (AttendanceStatus) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("student_row_${row.student.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF2B2930)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        border = borderStroke(
            width = 1.dp,
            color = Color(0xFF49454F).copy(alpha = 0.5f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Initials Avatar Badge
                val initials = remember(row.student) {
                    val f = row.student.firstName.firstOrNull()?.uppercase() ?: ""
                    val l = row.student.lastName.firstOrNull()?.uppercase() ?: ""
                    "$f$l"
                }
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(
                            when (row.status) {
                                AttendanceStatus.ABSENT -> Color(0xFF690005)
                                AttendanceStatus.PRESENT -> Color(0xFF00390A)
                                else -> Color(0xFF381E72)
                            }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = initials,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        color = when (row.status) {
                            AttendanceStatus.ABSENT -> Color(0xFFFFB4AB)
                            AttendanceStatus.PRESENT -> Color(0xFFB6FFB6)
                            else -> Color(0xFFD0BCFF)
                        }
                    )
                }

                Column {
                    Text(
                        text = "${row.student.lastName}, ${row.student.firstName}",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color(0xFFE6E1E5),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "ID: #${row.student.id.toString().takeLast(4)}-A",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF938F99),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Attendance selection buttons (P, A, T, J)
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatusCircleButton(
                    letter = "P",
                    description = "Presente",
                    selectedColor = ColorPresent,
                    isSelected = row.status == AttendanceStatus.PRESENT,
                    onClick = { onStatusChanged(AttendanceStatus.PRESENT) },
                    modifier = Modifier.testTag("status_present_${row.student.id}")
                )

                StatusCircleButton(
                    letter = "A",
                    description = "Ausente",
                    selectedColor = ColorAbsent,
                    isSelected = row.status == AttendanceStatus.ABSENT,
                    onClick = { onStatusChanged(AttendanceStatus.ABSENT) },
                    modifier = Modifier.testTag("status_absent_${row.student.id}")
                )

                StatusCircleButton(
                    letter = "T",
                    description = "Tarde",
                    selectedColor = ColorLate,
                    isSelected = row.status == AttendanceStatus.LATE,
                    onClick = { onStatusChanged(AttendanceStatus.LATE) },
                    modifier = Modifier.testTag("status_late_${row.student.id}")
                )

                StatusCircleButton(
                    letter = "J",
                    description = "Justificado",
                    selectedColor = ColorExcused,
                    isSelected = row.status == AttendanceStatus.EXCUSED,
                    onClick = { onStatusChanged(AttendanceStatus.EXCUSED) },
                    modifier = Modifier.testTag("status_excused_${row.student.id}")
                )
            }
        }
    }
}

@Composable
fun StatusCircleButton(
    letter: String,
    description: String,
    selectedColor: Color,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(
                if (isSelected) selectedColor else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            )
            .border(
                width = 1.dp,
                color = if (isSelected) Color.Transparent else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                shape = CircleShape
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = letter,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun HistoryTabContent(
    viewModel: AttendanceViewModel,
    historySummaries: List<HistorySummary>,
    onDateSelected: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Sesiones Archivadas",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = "Selecciona una fecha para ver o editar el registro completo.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            if (historySummaries.isEmpty()) {
                item {
                    EmptyState(
                        title = "Aún no hay historial",
                        description = "Los registros de asistencia de cada día aparecerán compilados en esta sección."
                    )
                }
            } else {
                items(historySummaries, key = { it.date }) { summary ->
                    HistorySummaryCard(summary = summary, onClick = { onDateSelected(summary.date) })
                }
            }
        }
    }
}

@Composable
fun HistorySummaryCard(
    summary: HistorySummary,
    onClick: () -> Unit
) {
    val formattedDate = remember(summary.date) {
        val date = LocalDate.parse(summary.date)
        date.format(DateTimeFormatter.ofPattern("EEEE d 'de' MMMM, yyyy", Locale("es", "ES")))
            .replaceFirstChar { it.uppercase() }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("history_card_${summary.date}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        border = borderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = formattedDate,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Icon(
                    imageVector = Icons.Default.KeyboardArrowRight,
                    contentDescription = "Ver detalles",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            
            Spacer(modifier = Modifier.height(12.dp))

            // Canvas horizontal stacked bar distribution
            CustomStackedBarChart(
                present = summary.presentCount,
                absent = summary.absentCount,
                late = summary.lateCount,
                excused = summary.excusedCount,
                total = summary.totalCount
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                StatBadge(label = "Presentes", count = summary.presentCount, color = ColorPresent)
                StatBadge(label = "Ausentes", count = summary.absentCount, color = ColorAbsent)
                StatBadge(label = "Tardes", count = summary.lateCount, color = ColorLate)
                StatBadge(label = "Justific.", count = summary.excusedCount, color = ColorExcused)
            }
        }
    }
}

@Composable
fun CustomStackedBarChart(
    present: Int,
    absent: Int,
    late: Int,
    excused: Int,
    total: Int,
    modifier: Modifier = Modifier
) {
    val unmarked = (total - (present + absent + late + excused)).coerceAtLeast(0)
    
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(12.dp)
            .clip(RoundedCornerShape(6.dp))
    ) {
        if (total == 0) {
            drawRect(color = ColorUnmarked)
        } else {
            val width = size.width
            val height = size.height

            val presentWidth = (present.toFloat() / total) * width
            val absentWidth = (absent.toFloat() / total) * width
            val lateWidth = (late.toFloat() / total) * width
            val excusedWidth = (excused.toFloat() / total) * width
            val unmarkedWidth = (unmarked.toFloat() / total) * width

            var currentX = 0f

            if (presentWidth > 0) {
                drawRect(
                    color = ColorPresent,
                    topLeft = Offset(currentX, 0f),
                    size = Size(presentWidth, height)
                )
                currentX += presentWidth
            }

            if (lateWidth > 0) {
                drawRect(
                    color = ColorLate,
                    topLeft = Offset(currentX, 0f),
                    size = Size(lateWidth, height)
                )
                currentX += lateWidth
            }

            if (excusedWidth > 0) {
                drawRect(
                    color = ColorExcused,
                    topLeft = Offset(currentX, 0f),
                    size = Size(excusedWidth, height)
                )
                currentX += excusedWidth
            }

            if (absentWidth > 0) {
                drawRect(
                    color = ColorAbsent,
                    topLeft = Offset(currentX, 0f),
                    size = Size(absentWidth, height)
                )
                currentX += absentWidth
            }

            if (unmarkedWidth > 0) {
                drawRect(
                    color = ColorUnmarked.copy(alpha = 0.3f),
                    topLeft = Offset(currentX, 0f),
                    size = Size(unmarkedWidth, height)
                )
            }
        }
    }
}

@Composable
fun StatBadge(label: String, count: Int, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = "$label: $count",
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun StudentsTabContent(
    viewModel: AttendanceViewModel,
    studentStats: List<StudentStat>,
    onStudentClicked: (Student) -> Unit
) {
    var query by remember { mutableStateOf("") }

    val filteredStats = remember(studentStats, query) {
        if (query.isBlank()) {
            studentStats
        } else {
            studentStats.filter {
                it.student.lastName.contains(query, ignoreCase = true) ||
                it.student.firstName.contains(query, ignoreCase = true)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Base de Alumnos",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = "Listado general de alumnos y rendimiento de asistencia.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        
        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("Buscar alumno en la base...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Buscar") },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { query = "" }) {
                        Icon(Icons.Default.Clear, contentDescription = "Limpiar")
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("students_database_search")
        )

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 80.dp) // Leave space for FAB
        ) {
            if (filteredStats.isEmpty()) {
                item {
                    EmptyState(
                        title = "No se encontraron alumnos",
                        description = "Prueba introduciendo otro término."
                    )
                }
            } else {
                items(filteredStats, key = { it.student.id }) { stat ->
                    StudentStatCard(stat = stat, onClick = { onStudentClicked(stat.student) })
                }
            }
        }
    }
}

@Composable
fun StudentStatCard(
    stat: StudentStat,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("student_stat_card_${stat.student.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        border = borderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stat.student.lastName,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = stat.student.firstName,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Registros: ${stat.totalSessions} | Pres: ${stat.presentCount} · Tard: ${stat.lateCount}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Visual Health Badge for student attendance rate
            val badgeColor = when {
                stat.totalSessions == 0 -> ColorUnmarked
                stat.attendancePercentage >= 90f -> ColorPresent
                stat.attendancePercentage >= 75f -> ColorLate
                else -> ColorAbsent
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(badgeColor.copy(alpha = 0.15f))
                    .border(1.dp, badgeColor.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "${stat.attendancePercentage.toInt()}%",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (badgeColor == ColorUnmarked) MaterialTheme.colorScheme.onSurface else badgeColor
                    )
                )
            }
        }
    }
}

@Composable
fun EmptyState(
    title: String,
    description: String
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 48.dp, horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.Info,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f),
            modifier = Modifier.size(56.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = description,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun AddStudentDialog(
    onDismiss: () -> Unit,
    onConfirm: (lastName: String, firstName: String) -> Unit
) {
    var lastName by remember { mutableStateOf("") }
    var firstName by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(20.dp)
            ) {
                Text(
                    text = "Añadir Alumno",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = lastName,
                    onValueChange = { lastName = it },
                    label = { Text("Apellido(s)") },
                    singleLine = true,
                    isError = isError && lastName.isBlank(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("add_student_lastname_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = firstName,
                    onValueChange = { firstName = it },
                    label = { Text("Nombre") },
                    singleLine = true,
                    isError = isError && firstName.isBlank(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("add_student_firstname_input")
                )

                if (isError) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Ambos campos son requeridos",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.labelSmall
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancelar")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (lastName.isNotBlank() && firstName.isNotBlank()) {
                                onConfirm(lastName.trim(), firstName.trim())
                            } else {
                                isError = true
                            }
                        },
                        modifier = Modifier.testTag("confirm_add_student_button")
                    ) {
                        Text("Guardar")
                    }
                }
            }
        }
    }
}

@Composable
fun StudentDetailDialog(
    student: Student,
    allRecords: StateFlow<List<AttendanceRecord>>,
    onDismiss: () -> Unit,
    onDelete: () -> Unit,
    onEdit: (lastName: String, firstName: String) -> Unit
) {
    val recordsList by allRecords.collectAsStateWithLifecycle()
    
    val studentRecords = remember(recordsList, student.id) {
        recordsList.filter { it.studentId == student.id }
            .sortedByDescending { it.date }
    }

    var isEditing by remember { mutableStateOf(false) }
    var editLastName by remember { mutableStateOf(student.lastName) }
    var editFirstName by remember { mutableStateOf(student.firstName) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 24.dp)
        ) {
            Column(
                modifier = Modifier
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(20.dp)
            ) {
                if (!isEditing) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = student.fullName,
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "ID Alumno: #${student.id}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        
                        Row {
                            IconButton(onClick = { isEditing = true }) {
                                Icon(Icons.Default.Edit, contentDescription = "Editar", tint = MaterialTheme.colorScheme.primary)
                            }
                            IconButton(onClick = onDelete) {
                                Icon(Icons.Default.Delete, contentDescription = "Eliminar", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Historial de Clases",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (studentRecords.isEmpty()) {
                            item {
                                Text(
                                    text = "Este alumno no tiene asistencias registradas aún.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(vertical = 12.dp)
                                )
                            }
                        } else {
                            items(studentRecords) { record ->
                                val dateStr = record.date
                                val formatted = remember(dateStr) {
                                    val d = LocalDate.parse(dateStr)
                                    d.format(DateTimeFormatter.ofPattern("dd MMM, yyyy", Locale("es", "ES")))
                                }
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = formatted, style = MaterialTheme.typography.bodyMedium)
                                    
                                    val (color, text) = when (record.status) {
                                        AttendanceStatus.PRESENT -> ColorPresent to "Presente"
                                        AttendanceStatus.ABSENT -> ColorAbsent to "Ausente"
                                        AttendanceStatus.LATE -> ColorLate to "Tarde"
                                        AttendanceStatus.EXCUSED -> ColorExcused to "Justificado"
                                    }
                                    
                                    Box(
                                        modifier = Modifier
                                            .clip(CircleShape)
                                            .background(color.copy(alpha = 0.12f))
                                            .padding(horizontal = 10.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = text,
                                            color = color,
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Cerrar")
                    }
                } else {
                    // Editing Form
                    Text(
                        text = "Editar Alumno",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = editLastName,
                        onValueChange = { editLastName = it },
                        label = { Text("Apellido(s)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = editFirstName,
                        onValueChange = { editFirstName = it },
                        label = { Text("Nombre") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { isEditing = false }) {
                            Text("Cancelar")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (editLastName.isNotBlank() && editFirstName.isNotBlank()) {
                                    onEdit(editLastName.trim(), editFirstName.trim())
                                    isEditing = false
                                }
                            }
                        ) {
                            Text("Guardar Cambios")
                        }
                    }
                }
            }
        }
    }
}
