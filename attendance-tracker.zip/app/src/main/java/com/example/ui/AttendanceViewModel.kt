package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate

@OptIn(ExperimentalCoroutinesApi::class)
class AttendanceViewModel(private val repository: AttendanceRepository) : ViewModel() {

    private val _selectedDate = MutableStateFlow(LocalDate.now().toString())
    val selectedDate: StateFlow<String> = _selectedDate.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _statusFilter = MutableStateFlow<AttendanceFilter>(AttendanceFilter.ALL)
    val statusFilter: StateFlow<AttendanceFilter> = _statusFilter.asStateFlow()

    val students: StateFlow<List<Student>> = repository.allStudents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allRecords: StateFlow<List<AttendanceRecord>> = repository.allAttendanceRecords
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentDateRecords: StateFlow<List<AttendanceRecord>> = _selectedDate
        .flatMapLatest { date -> repository.getAttendanceForDate(date) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val attendanceRows: StateFlow<List<AttendanceRow>> = combine(
        students,
        currentDateRecords,
        searchQuery,
        statusFilter
    ) { studentList, recordList, query, filter ->
        val recordMap = recordList.associateBy { it.studentId }
        studentList.map { student ->
            val record = recordMap[student.id]
            AttendanceRow(
                student = student,
                status = record?.status
            )
        }.filter { row ->
            val matchesSearch = query.isBlank() || 
                row.student.lastName.contains(query, ignoreCase = true) ||
                row.student.firstName.contains(query, ignoreCase = true)
            
            val matchesFilter = when (filter) {
                AttendanceFilter.ALL -> true
                AttendanceFilter.PRESENT -> row.status == AttendanceStatus.PRESENT
                AttendanceFilter.ABSENT -> row.status == AttendanceStatus.ABSENT
                AttendanceFilter.LATE -> row.status == AttendanceStatus.LATE
                AttendanceFilter.EXCUSED -> row.status == AttendanceStatus.EXCUSED
                AttendanceFilter.UNMARKED -> row.status == null
            }

            matchesSearch && matchesFilter
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val historySummaries: StateFlow<List<HistorySummary>> = allRecords
        .map { records ->
            records.groupBy { it.date }.map { (date, recordsForDate) ->
                val present = recordsForDate.count { it.status == AttendanceStatus.PRESENT }
                val absent = recordsForDate.count { it.status == AttendanceStatus.ABSENT }
                val late = recordsForDate.count { it.status == AttendanceStatus.LATE }
                val excused = recordsForDate.count { it.status == AttendanceStatus.EXCUSED }
                HistorySummary(
                    date = date,
                    totalCount = recordsForDate.size,
                    presentCount = present,
                    absentCount = absent,
                    lateCount = late,
                    excusedCount = excused
                )
            }.sortedByDescending { it.date }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val studentStats: StateFlow<List<StudentStat>> = combine(
        students,
        allRecords
    ) { studentList, records ->
        val recordGroups = records.groupBy { it.studentId }
        studentList.map { student ->
            val studentRecords = recordGroups[student.id] ?: emptyList()
            val total = studentRecords.size
            val present = studentRecords.count { it.status == AttendanceStatus.PRESENT }
            val absent = studentRecords.count { it.status == AttendanceStatus.ABSENT }
            val late = studentRecords.count { it.status == AttendanceStatus.LATE }
            val excused = studentRecords.count { it.status == AttendanceStatus.EXCUSED }
            
            StudentStat(
                student = student,
                totalSessions = total,
                presentCount = present,
                absentCount = absent,
                lateCount = late,
                excusedCount = excused,
                attendancePercentage = if (total > 0) ((present + late + excused).toFloat() / total * 100) else 100f
            )
        }.sortedBy { it.student.lastName }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun updateSelectedDate(date: String) {
        _selectedDate.value = date
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun updateStatusFilter(filter: AttendanceFilter) {
        _statusFilter.value = filter
    }

    fun updateAttendance(studentId: Int, status: AttendanceStatus) {
        viewModelScope.launch {
            val record = AttendanceRecord(
                date = _selectedDate.value,
                studentId = studentId,
                status = status
            )
            repository.insertAttendanceRecord(record)
        }
    }

    fun markAllForSelectedDate(status: AttendanceStatus) {
        viewModelScope.launch {
            val date = _selectedDate.value
            val currentStudents = students.value
            val records = currentStudents.map { student ->
                AttendanceRecord(date = date, studentId = student.id, status = status)
            }
            repository.insertAttendanceRecords(records)
        }
    }

    fun clearAllForSelectedDate() {
        viewModelScope.launch {
            repository.deleteAttendanceForDate(_selectedDate.value)
        }
    }

    fun addStudent(lastName: String, firstName: String) {
        viewModelScope.launch {
            val student = Student(lastName = lastName, firstName = firstName)
            repository.insertStudent(student)
        }
    }

    fun deleteStudent(student: Student) {
        viewModelScope.launch {
            repository.deleteStudent(student)
        }
    }
    
    fun editStudent(student: Student) {
        viewModelScope.launch {
            repository.updateStudent(student)
        }
    }
}

class AttendanceViewModelFactory(private val repository: AttendanceRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AttendanceViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return AttendanceViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

data class AttendanceRow(
    val student: Student,
    val status: AttendanceStatus?
)

enum class AttendanceFilter {
    ALL, PRESENT, ABSENT, LATE, EXCUSED, UNMARKED
}

data class HistorySummary(
    val date: String,
    val totalCount: Int,
    val presentCount: Int,
    val absentCount: Int,
    val lateCount: Int,
    val excusedCount: Int
)

data class StudentStat(
    val student: Student,
    val totalSessions: Int,
    val presentCount: Int,
    val absentCount: Int,
    val lateCount: Int,
    val excusedCount: Int,
    val attendancePercentage: Float
)
