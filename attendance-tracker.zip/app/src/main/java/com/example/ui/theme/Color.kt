package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Elegant Dark Palette Constants
val DarkBackground = Color(0xFF1C1B1F)
val DarkTextMain = Color(0xFFE6E1E5)
val DarkTextSecondary = Color(0xFF938F99)

val PrimaryPurple = Color(0xFF4F378B)
val PrimaryPurpleLight = Color(0xFFD0BCFF)
val OnPrimaryPurple = Color(0xFF381E72)
val OnPrimaryContainer = Color(0xFFEADDFF)

val SecondaryContainerDark = Color(0xFF332D41)
val OnSecondaryContainerDark = Color(0xFFE8DEF8)

val SurfaceDark = Color(0xFF1C1B1F)
val SurfaceVariantDark = Color(0xFF2B2930)
val OnSurfaceVariantDark = Color(0xFFCAC4D0)

val BorderOutlineDark = Color(0xFF49454F)

// Status colors
val ColorPresentDark = Color(0xFFB6FFB6)
val ColorAbsentDark = Color(0xFFF2B8B5)
val ColorLateDark = Color(0xFFFFD54F)
val ColorExcusedDark = Color(0xFF90CAF9)
val ColorUnmarkedDark = Color(0xFF938F99)

