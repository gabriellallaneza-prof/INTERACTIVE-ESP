package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = PrimaryPurpleLight,
    onPrimary = OnPrimaryPurple,
    primaryContainer = PrimaryPurple,
    onPrimaryContainer = OnPrimaryContainer,
    secondary = PrimaryPurpleLight,
    onSecondary = OnPrimaryPurple,
    secondaryContainer = SecondaryContainerDark,
    onSecondaryContainer = OnSecondaryContainerDark,
    background = DarkBackground,
    onBackground = DarkTextMain,
    surface = SurfaceDark,
    onSurface = DarkTextMain,
    surfaceVariant = SurfaceVariantDark,
    onSurfaceVariant = OnSurfaceVariantDark,
    outline = BorderOutlineDark,
    outlineVariant = BorderOutlineDark,
    error = ColorAbsentDark,
    onError = Color(0xFF600004)
  )

private val LightColorScheme = DarkColorScheme // Default both to Elegant Dark for consistent design theme application

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Force Dark theme for the "Elegant Dark" look
  dynamicColor: Boolean = false, // Disable dynamic material color to keep the custom brand look
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
