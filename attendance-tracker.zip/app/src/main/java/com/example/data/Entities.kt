package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter

@Entity(tableName = "students")
data class Student(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val lastName: String,
    val firstName: String,
    val isActive: Boolean = true
) {
    val fullName: String
        get() = "$lastName, $firstName"
}

@Entity(
    tableName = "attendance_records",
    primaryKeys = ["date", "studentId"]
)
data class AttendanceRecord(
    val date: String, // format "yyyy-MM-dd"
    val studentId: Int,
    val status: AttendanceStatus
)

enum class AttendanceStatus {
    PRESENT,
    ABSENT,
    LATE,
    EXCUSED
}

class Converters {
    @TypeConverter
    fun fromStatus(status: AttendanceStatus): String {
        return status.name
    }

    @TypeConverter
    fun toStatus(value: String): AttendanceStatus {
        return AttendanceStatus.valueOf(value)
    }
}
