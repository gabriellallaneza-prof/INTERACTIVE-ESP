package com.example.data

const val PREDEFINED_STUDENTS_CSV = """Apellido(s),Nombre
Abraham,Abigail
Abraham,Laura
Aguilera Raciti,Catalina
ALONSO,LEONARDO
AMARANTE,ÁNGEL
ABA,Marcos
Battolla,Juani
BEGBEDER,PABLO LUIS ISNARDO
Beltramella,Ezequiel
BERNAL HERRERA,DANIEL ESTEBAN
Bevacqua,Mayra
BORCANO,JOAQUIN
BRICKA GARRO,ANDRES LAUTARO
BUSTAMANTE,FRANCISCO RAUL
CANEVELLO,Thiago Andres
CEJAS,WILLIAM LEONEL
Christensen,Eros
CIGANDA,Agustin
Coria,Agustín Sebastián
Cossio,Ignacio
CRIADO ERRECA,FELIPE
CRONI,ROCCO
CUELI,NAHIARA
Cuestas,Lautaro Ezequiel
DAGARO,RYU
DAVILA,TOBIAS NICOLAS
DEL RIO FALATOVICH,MARILYN MAGDALENE
DOMINGUEZ,MORENA GUADALUPE
Echarri Agesta,Juan Daniel
Elizondo,Ulises
ELORDI FONTANA,TOMÁS
Erreca,Ignacio
ESAINS ALLMANG,SIMON
Escudero,Nicolás
ESTUARTE,JOEL
FAZZIO,NAHUEL
Fernandez,Pablo Benjamín
FERNANDEZ CAMBEIRO,CELESTE
Fernández Curuchet,Martín
FRANCO,JOAQUIN
FRANCO,MARIA SOLEDAD
Frisorger,Catalina
GANDOLFO,DIEGO MARIANO
GARCIA,MARIA RUTH
Genson,Franco Nahuel
GIGENA,SIMON
GIMÉNEZ,ALAN IAN
GIMENEZ RUEDA,FACUNDO LAUTARO
GIUDICE,JUAN BAUTISTA
Godoy Cotoloni,Franco Ariel
GOMEZ,MAICO OMAR
Goñi,Santino
GONZALEZ,FEDERICO
GONZALEZ,MARTINA MAGALÍ
GONZALEZ,MATIAS
Gonzalez Alvarez,sebasten
GRANERO ZAPICO,THIAGO
Guevara,Joaquin
HEREDIA,NEHEMIAS GADIEL
JAURENA,GABRIEL
JUÁREZ,Ana Elisa
KENNARD,JACK ALEXANDER
LABALA,PABLO DAVID
Lamtzev,Alejandro
LAPOLLA,TOMAS
Latasa,Tomas
Leiva,Francisco Benjamin
Llanos Gimenez,Fermin
Lupo,Manuel Agustin
MACHADO,MAXIMILIANO MARCELO
Maneri,Tomás Abel
Mansilla,Facundo Ivan
Manso,Julián
Martin,Milagros
MARTINEZ,BAUTISTA
Martínez Harispe,Ignacio
Martinez Ocampo,Mora
MARTÍNEZ SHEMI,KATRINA
MARTINEZ WUSIKOSKY,IAN
Martorell,Valentin
Massolo,Federico Gerardo
MAZZOCCHI,JULIETA DAIANA
Meclazcke,Athos
MÉDICO,KEVIN ALEJO
Medina,Tomás
Melchior,Henry
Menna,Virginia
MENSCHIK,AXEL
MESAS,AGUSTIN
MIRAGLIO,Sebastián
MORENO,CRISTIAN ARIEL
MORTARINI FORCHETTI,VIOLETA
Murúa,Carolina Ángeles
NAVARRO,VALENTIN
Oddi,Thiago Román
OLIVER,Ana Belén
Ollearo Luguercio,Nicolás Gabriel
ONGARO,SANTINO
PALMA,BAUTISTA
PAZ,MARIA LUCIANA
PEÑA ANTA,LUCILA
PEREZ,MILAGROS CAROLINA
PÉREZ LOMES,NICOLÁS
PONTAROLI,SIMON
REY CALVO,SOL MELINA
RIVAROLA,SANTIAGO EZEQUIEL
Rodriguez,Pablo Octavio
Rodriguez,Tomas
RODRIGUEZ,CESAR IGNACIO
RODRIGUEZ,Lourdes Josefina
Rodríguez,Candela Agostina
RODRIGUEZ TOUYARON,MATIAS ELI
Rojo Acuña,Luca
RUIZ,JUAN IGNACIO
Russo,Matias
SALVIA,LORENZO
Sanchez,Ayelén
Sanchez,Nicolás Gabriel
Sarlangue Pontaroli,Justo
SCHWINDT,TIZIANO
Sierra,Lis
SILKA,LUCAS
SOCOBEHERE,MATIAS
SOSA,LAUTARO
SOSA MONTOYA,YAHIR ARIEL
SOTO,LUCAS DAVID
SOUTO ARUFE,FACUNDO ANDRÉS
SUHIT,BRIAN ANDRES
TEDESCO LONGO,LUCA THIAGO
Temudio,Jerónimo Ignacio
Teodoro,Jose Daniel
Timo,Pablo
TORRES,AGUSTINA
TORRES,BRIAN AGUSTIN
TORRES,MARCOS JAVIER
Valderrey,Julian
VALLESILLO CORDERO,SANTIAGO
VAQUERO,SANTIAGO
VARGAS,MICAELA GISEL
VERNI,SANTINO
VIDELA,BENJAMIN
VILLAGRAS COVINI,IÑAKI
WALTER,SANTIAGO
WALTER,THOMAS
ZELAYA,SANTIAGO
ZERLING TORERO,NATASHA
ZIJLSTRA VERGARA,KIARA ROCIO
ZUBIGARAY,Lara
Zuzulich,Micaela"""

fun parsePredefinedStudents(): List<Student> {
    return PREDEFINED_STUDENTS_CSV.lineSequence()
        .drop(1) // Drop the "Apellido(s),Nombre" header
        .filter { it.isNotBlank() }
        .mapNotNull { line ->
            val parts = line.split(",")
            if (parts.size >= 2) {
                Student(
                    lastName = parts[0].trim(),
                    firstName = parts[1].trim()
                )
            } else {
                null
            }
        }
        .toList()
}
