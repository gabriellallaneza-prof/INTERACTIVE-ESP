package com.example.data

import kotlinx.coroutines.flow.Flow

class AttendanceRepository(private val attendanceDao: AttendanceDao) {

    val allStudents: Flow<List<Student>> = attendanceDao.getAllStudents()
    
    val allAttendanceRecords: Flow<List<AttendanceRecord>> = attendanceDao.getAllAttendanceRecords()

    fun getAttendanceForDate(date: String): Flow<List<AttendanceRecord>> {
        return attendanceDao.getAttendanceForDate(date)
    }

    suspend fun insertStudent(student: Student): Long {
        return attendanceDao.insertStudent(student)
    }

    suspend fun deleteStudent(student: Student) {
        attendanceDao.deleteStudent(student)
    }

    suspend fun updateStudent(student: Student) {
        attendanceDao.updateStudent(student)
    }

    suspend fun insertAttendanceRecord(record: AttendanceRecord) {
        attendanceDao.insertAttendanceRecord(record)
    }

    suspend fun insertAttendanceRecords(records: List<AttendanceRecord>) {
        attendanceDao.insertAttendanceRecords(records)
    }

    suspend fun deleteAttendanceForDate(date: String) {
        attendanceDao.deleteAttendanceForDate(date)
    }
}
